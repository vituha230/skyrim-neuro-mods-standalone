set(sources
	main.cpp
)
